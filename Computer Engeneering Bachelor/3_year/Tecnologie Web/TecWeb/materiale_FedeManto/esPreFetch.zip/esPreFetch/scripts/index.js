let btn = document.getElementById('btn');
let num = document.getElementById('num');
let download = document.getElementById('download');
let songs = [];
let songsId = [];
btn.addEventListener('click', handleClick);

function handleClick() {
	console.log("Num: " + num.value);
	console.log(songsId + " ");
	if(songsId.includes(parseInt(num.value))) {
		console.log("Canzone scaricata precedentemente");
	} else {
		// Canzone da scaricare
		console.log("Scaricameto canzone...");
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "S1", true);
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		
		xhr.onreadystatechange = function() {
			if(xhr.readyState === 4 && xhr.status === 200) {
				let response = xhr.responseText;
				let jsObject = JSON.parse(response);
				console.log(response);
				
				songs.push(jsObject.title);
				songsId.push(jsObject.id);
				download.innerText += jsObject.title + '\n';
			}
		}
		
		xhr.send("num=" + num.value);
	}
}