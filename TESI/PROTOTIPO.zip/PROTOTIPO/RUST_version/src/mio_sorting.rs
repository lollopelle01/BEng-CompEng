// Bubble Sort iterativo
pub fn bubble_sort(data: &mut Vec<char>) {
    let len = data.len();
    for i in 0..len {
        for j in 0..len - i - 1 {
            if data[j] > data[j + 1] {
                data.swap(j, j + 1);
            }
        }
    }
}

// Merge Sort iterativo
pub fn merge_sort<T: std::marker::Copy + std::clone::Clone + std::cmp::PartialOrd>(x: &mut [T]) {
	let n = x.len();
	let m = n / 2;
 
	if n <= 1 {
		return;
	}
 
	merge_sort(&mut x[0..m]);
	merge_sort(&mut x[m..n]);
 
	let mut y: Vec<T> = x.to_vec();
 
	merge(&x[0..m], &x[m..n], &mut y[..]);
 
	x.copy_from_slice(&y);
}

fn merge<T: std::cmp::PartialOrd + Copy>(x1: &[T], x2: &[T], y: &mut [T]) {
    assert_eq!(x1.len() + x2.len(), y.len());
    let mut i = 0;
    let mut j = 0;
    let mut k = 0;
    while i < x1.len() && j < x2.len() {
        if x1[i] < x2[j] {
            y[k] = x1[i];
            k += 1;
            i += 1;
        } else {
            y[k] = x2[j];
            k += 1;
            j += 1;
        }
    }
    if i < x1.len() {
        y[k..].copy_from_slice(&x1[i..]);
    }
    if j < x2.len() {
        y[k..].copy_from_slice(&x2[j..]);
    }
}

pub fn quick_sort<T: std::cmp::PartialOrd>(arr: &mut [T]) {
    let len = arr.len();
    _quick_sort(arr, 0, (len - 1) as isize);
}

fn _quick_sort<T: std::cmp::PartialOrd>(arr: &mut [T], low: isize, high: isize) {
    if low < high {
        let p = partition(arr, low, high);
        _quick_sort(arr, low, p - 1);
        _quick_sort(arr, p + 1, high);
    }
}

fn partition<T: std::cmp::PartialOrd>(arr: &mut [T], low: isize, high: isize) -> isize {
    let pivot = high as usize;
    let mut store_index = low - 1;
    let mut last_index = high;

    loop {
        store_index += 1;
        while arr[store_index as usize] < arr[pivot] {
            store_index += 1;
        }
        last_index -= 1;
        while last_index >= 0 && arr[last_index as usize] > arr[pivot] {
            last_index -= 1;
        }
        if store_index >= last_index {
            break;
        } else {
            arr.swap(store_index as usize, last_index as usize);
        }
    }
    arr.swap(store_index as usize, pivot as usize);
    store_index
}					


// pub fn quick_sort_recursive<T: Ord + Clone + Copy>(data: &mut [T]) {
//     let len = data.len();
//     if len <= 1 {
//         return;
//     }

//     let pivot_index = partition(data);

//     if pivot_index > 1 {
//         quick_sort_recursive(&mut data[0..pivot_index]);
//     }

//     if pivot_index + 1 < len {
//         quick_sort_recursive(&mut data[pivot_index + 1..len]);
//     }
// }

// fn partition<T: Ord + Clone + Copy>(data: &mut [T]) -> usize {
//     let pivot = data[0];
//     let mut i = 0;
//     let mut j = data.len();

//     loop {
//         while i < data.len() && data[i] <= pivot {
//             i += 1;
//         }

//         while j > 0 && data[j - 1] > pivot {
//             j -= 1;
//         }

//         if i >= j {
//             break;
//         }

//         data.swap(i, j - 1);
//         i += 1;
//         j -= 1;
//     }

//     j
// }
