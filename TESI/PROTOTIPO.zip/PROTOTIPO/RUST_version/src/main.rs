/*** MODULI ***************************************************************************************************/
mod mio_sorting;

use std::env;
//use std::fs;
// use std::thread;
use std::fs::File;
use std::io::{Write, Read};
use mio_sorting::{bubble_sort, merge_sort, quick_sort};
// use std::process::{Command, exit};


/*** FUNZIONI ***************************************************************************************************/
pub fn create_file(path: &str, content: &str) {
    let mut output = File::create(path).expect(&format!("Error creating {}", path));
    output.write_all(content.as_bytes()).unwrap();
}

pub fn read_file(path: &str) -> String {
    let mut f = File::open(path).expect(&format!("Error opening {}", path));
    let mut s = String::new();
    match f.read_to_string(&mut s) {
        Ok(_) => s,
        Err(e) => e.to_string(),
    }
}

// fn write_thread_output(path_input: &str, content: &[char], thread_id: i32) {
//     // Implementazione della scrittura di un thread
//     let mut output_file_name = path_input.replace("input", "output"); // metto nella directory giusta
//     output_file_name = output_file_name.replace(".txt", format!("_{}.txt", thread_id).as_str());

//     let content_str: String = content.iter().collect();
//     create_file(&output_file_name, &content_str);
// }

// fn print_current_dir(){
//     // Ottieni la directory corrente come PathBuf
//     if let Ok(current_dir) = env::current_dir() {
//         // Stampa la directory corrente come stringa
//         if let Some(dir_str) = current_dir.to_str() {
//             println!("Directory corrente: {}", dir_str);
//         } else {
//             println!("Impossibile convertire la directory corrente in una stringa valida.");
//         }
//     } else {
//         println!("Impossibile ottenere la directory corrente.");
//     }
// }

// fn exec_command(command: &str, args: &[&str]) {
//     // Esegui il comando con gli argomenti forniti
//     let output = Command::new(command)
//         .args(args)
//         .output();

//     // Gestisci il risultato dell'esecuzione del comando
//     match output {
//         Ok(result) => {
//             // Controlla se il comando ha restituito un output corretto
//             if result.status.success() {
//                 // Stampa l'output
//                 if let Ok(output_str) = String::from_utf8(result.stdout) {
//                     print!("{}", output_str);
//                 } else {
//                     eprintln!("Errore nel convertire l'output in una stringa valida");
//                 }
//             } else {
//                 eprintln!("Il comando {} ha restituito un errore con lo stato {}", command, result.status);
//                 exit(result.status.code().unwrap_or(1));
//             }
//         }
//         Err(err) => {
//             eprintln!("Errore nell'eseguire il comando {}: {}", command, err);
//             exit(1);
//         }
//     }
// }

/*** MAIN ***************************************************************************************************/
fn main() {
    // Ottieni la lista degli argomenti della riga di comando
    let args: Vec<String> = env::args().collect();

    let mut carico = 0;
    let mut algoritmo = 0;
    // let mut threads = 0;

    // Verifica se ci sono argomenti
    if args.len() == 2 {
        // Ottieni il primo parametro (indice 1 poiché l'indice 0 è il nome del programma)
        carico = args[1].parse::<i32>().unwrap_or(-1); //println!("carico: {}", carico);
        algoritmo = args[2].parse::<i32>().unwrap_or(-1); //println!("algoritmo: {}", algoritmo);
        // threads = args[3].parse::<i32>().unwrap_or(-1); //println!("num_threads: {}", algoritmo);
        
    } else {
        println!("Errore nei parametri.");
        return;
    }

    // Leggo il contenuto
    let mut input_file_name = "";
    match carico {
        1 => {input_file_name = "files_input/1KB.txt";}
        2 => {input_file_name = "files_input/10KB.txt";}
        3 => {input_file_name = "files_input/100KB.txt";}
        4 => {input_file_name = "files_input/1MB.txt";}
        5 => {input_file_name = "files_input/10MB.txt";} 
        6 => {input_file_name = "files_input/100MB.txt";} 
        7 => {input_file_name = "files_input/500MB.txt";}
        _ => {println!("Carico non gestito");}
    }
    let mut content: Vec<char> = read_file(input_file_name).chars().collect();

    // Elaboro il contenuto
    match algoritmo {
        1 => {bubble_sort(&mut content);}
        2 => {merge_sort(&mut content);}
        3 => {quick_sort(&mut content);}
        _ => {println!("Algoritmo non gestito");}
    }

    // Threading
    // if threads == 0{ // Scrittura del processo
        let output_file_name = input_file_name.replace("input", "output");
        create_file(&output_file_name, &content.iter().collect::<String>());
    // }
    // else{ // Scrittura dei threads
    //     let mut handles = vec![];

    //     // Creiamo ed eseguiamo i threada
    //     for i in 0..threads {
    //         let thread_content = content.to_vec(); // Copia l'intero contenuto per ogni thread
    //         let handle = thread::spawn(move || {
    //             write_thread_output(input_file_name, &thread_content, i);
    //         });

    //         handles.push(handle);
    //     }

    //     // Attendere che tutti i threads terminino
    //     for handle in handles {
    //         handle.join().unwrap();
    //     }
    // }
}