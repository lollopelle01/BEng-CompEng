/* MODULI *******************************************************************************************************/
const fs = require('fs'); // per I/O da file
const { bubbleSort, mergeSort, quickSort } = require('./mioSorting'); // per sorting
const { cpuAverage } = require('./cpu'); // per misurazione cpu, internamente al processo
const { Worker } = require('worker_threads'); // per threading

/* FUNZIONI *******************************************************************************************************/

// function CPUusage(){
//     // Ottieni informazioni sulla CPU
//     const cpuInfo = os.cpus();

//     // Calcola l'utilizzo totale della CPU
//     const totalUsage = cpuInfo.reduce((acc, cpu) => acc + cpu.times.user + cpu.times.sys, 0);

//     // Calcola l'utilizzo percentuale rispetto al tempo totale
//     const totalCPUTime = totalUsage / cpuInfo.length;
//     const totalCPUTimePercentage = (totalCPUTime / os.uptime()) * 100;

//     return totalCPUTimePercentage.toFixed(2);
// }

/* MISURAZIONE *******************************************************************************************************/
// var benchMark = {
//     Input: {
//         T_i: undefined,
//         T_f: undefined,
//         T_d: undefined,
//         CPU_i: undefined,
//         CPU_f: undefined,
//         CPU_100: undefined,
//         MEM_i : undefined,
//         MEM_f : undefined,
//         MEM_100 : undefined
//     },
//     Elab: {
//         T_i: undefined,
//         T_f: undefined,
//         T_d: undefined,
//         CPU_i: undefined,
//         CPU_f: undefined,
//         CPU_100: undefined,
//         MEM_i : undefined,
//         MEM_f : undefined,
//         MEM_100 : undefined
//     },
//     Thread: {
//         T_i: undefined,
//         T_f: undefined,
//         T_d: undefined,
//         CPU_i: undefined,
//         CPU_f: undefined,
//         CPU_100: undefined,
//         MEM_i : undefined,
//         MEM_f : undefined,
//         MEM_100 : undefined
//     },
//     Output: {
//         T_i: undefined,
//         T_f: undefined,
//         T_d: undefined,
//         CPU_i: undefined,
//         CPU_f: undefined,
//         CPU_100: undefined,
//         MEM_i : undefined,
//         MEM_f : undefined,
//         MEM_100 : undefined
//     }
// };

// var benchMark_final = {
//     Input: {
//         T_d: undefined,
//         CPU_100: undefined,
//         MEM_100 : undefined
//     },
//     Elab: {
//         T_d: undefined,
//         CPU_100: undefined,
//         MEM_100 : undefined
//     },
//     Thread: {
//         T_d: undefined,
//         CPU_100: undefined,
//         MEM_100 : undefined
//     },
//     Output: {
//         T_d: undefined,
//         CPU_100: undefined,
//         MEM_100 : undefined
//     }
// };

/* PARAMETRI *******************************************************************************************************/
var complessità_IO = process.argv[2]; // 1, 2, 3, 4
var complessità_operazione = process.argv[3]; // 1, 2, 3
// var numero_thread = process.argv[4]; // a piacere [0, 10, 100, 1000]


/*** ESECUZIONE *******************************************************************************************************/

// Scelta del file in base alla complessità
var path;
switch(complessità_IO){
    case "1" : path = "../RUST_version/files_input/1KB.txt"; break;
    case "2" : path = "../RUST_version/files_input/10KB.txt"; break;
    case "3" : path = "../RUST_version/files_input/100KB.txt"; break;
    case "4" : path = "../RUST_version/files_input/1MB.txt"; break;
    case "5" : path = "../RUST_version/files_input/10MB.txt"; break;
    case "6" : path = "../RUST_version/files_input/100MB.txt"; break;
    // case "7" : path = "../RUST_version/files_input/500MB.txt"; break; troppo utilizzo di memoria
}

// Leggo il contenuto e lo salvo in memoria
let contenuto = [];

// Misurazione pre-lettura
// benchMark.Input.T_i = performance.now();
// benchMark.Input.CPU_i = cpuAverage();
// benchMark.Input.MEM_i = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0; 

fs.readFile(path, 'utf8', async (err, data) => {
    if (err) {
        console.error('Errore durante la lettura del file:', err);
        return;
    }

    // Misurazione post-lettura
    // benchMark.Input.T_f = performance.now();
    // benchMark.Input.CPU_f = cpuAverage();
    // benchMark.Input.MEM_f = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;

    // Da stringa ad array
    contenuto = data.split(''); 

    // Misurazione pre-elaborazione
    // benchMark.Elab.T_i = performance.now();
    // benchMark.Elab.CPU_i = cpuAverage(); 
    // benchMark.Elab.MEM_i = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;
    
    // Elaboro il contenuto
    var contenuto_ordinato;
    switch(complessità_operazione){
        case "1" : contenuto_ordinato = bubbleSort(contenuto); break;
        case "2" : contenuto_ordinato = mergeSort(contenuto); break;
        case "3" : contenuto_ordinato = quickSort(contenuto); break;
    }
    // console.log(contenuto_ordinato);

    // Misurazione post-elaborazione
    // benchMark.Elab.T_f = performance.now();
    // benchMark.Elab.CPU_f = cpuAverage();
    // benchMark.Elab.MEM_f = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;
    
    // Sclego se fare scrittura con thread o senza
    path = path.replace("input", "output");
    var testo = contenuto_ordinato.toString().replace(/,/g, ""); // tolgo le virgole dal testo

    // Gestione threading
    // if(numero_thread==0){ // Scrittura normale -> no thread
        // Misurazione pre-scrittura
        // benchMark.Output.T_i = performance.now();
        // benchMark.Output.CPU_i = cpuAverage();
        // benchMark.Output.MEM_i = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;

        // Scrittura
        fs.writeFile(path, testo, 'utf8', (err) => {
            if (err) {
                console.error('Errore durante la scrittura del file:', err);
                return;
            }
        });

        // Misurazione post-scrittura
        // benchMark.Output.T_f = performance.now();
        // benchMark.Output.CPU_f = cpuAverage();
        // benchMark.Output.MEM_f = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;
    // }
    // else{ // Scrittura con thread

    //     // Misurazione pre-threading
    //     // benchMark.Thread.T_i = performance.now();
    //     // benchMark.Thread.CPU_i = cpuAverage();
    //     // benchMark.Thread.MEM_i = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;

    //     // Array di promesse per tracciare l'avanzamento di ogni thread
    //     const threadPromises = [];

    //     // Avvio tutti i thread
    //     for(let i=0; i<numero_thread; i++){ 
    //         const worker = new Worker('./thread.js');
    //         let fileName = path.replace(".txt", "_" + i + ".txt"); // garantisco N file diversi

    //         // Avvio il thread dicendogli su che file scrivere e cosa scrivere
    //         worker.postMessage([fileName, testo]);

    //         // Creo una promessa per il thread corrente
    //         const threadPromise = new Promise((resolve) => {
    //             // Ricevo dal thread le misurazioni sulla sua scrittura
    //             worker.on('message', (benchmark) => {
    //                 // Risultato della promessa
    //                 resolve(benchmark);
    //             });
    //         });

    //         threadPromises.push(threadPromise);
    //     }

    //     // Aspetto tutti i thread abbiano scritto
    //     Promise.all(threadPromises)
    //     .then((misurazioniThreads) => {     // misurazioniThreads --> array di risultati di promesse

    //         // Misurazione post-threading
    //         // benchMark.Thread.T_f = performance.now();
    //         // benchMark.Thread.CPU_f = cpuAverage();
    //         // benchMark.Thread.MEM_f = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100.0;

    //         // Inizializzo misurazioni finali su scrittura
    //         // benchMark.Output.T_d = 0;
    //         // benchMark.Output.CPU_100 = 0;
    //         // benchMark.Output.MEM_100 = 0;

    //         // Misurazione finale sulle scritture --> media di tutte le misurazioni
    //         // for (var m of misurazioniThreads) {
    //         //     // Somma
    //         //     benchMark.Output.T_d += m.Output.T_d;
    //         //     benchMark.Output.CPU_100 += m.Output.CPU_100;
    //         //     benchMark.Output.MEM_100 += m.Output.MEM_100;
    //         // }

    //         // Divisione
    //         // benchMark.Output.T_d = benchMark.Output.T_d / misurazioniThreads.length;
    //         // benchMark.Output.CPU_100 = benchMark.Output.CPU_100 / misurazioniThreads.length;
    //         // benchMark.Output.MEM_100 = benchMark.Output.MEM_100 / misurazioniThreads.length;
    //     });
    // }

    /** MISURAZIONI FINALI **********************************************************************************************/
    // // Misurazioni finali sulla lettura
    // benchMark.Input.T_d = benchMark.Input.T_f - benchMark.Input.T_i;
    // benchMark.Input.CPU_100 =  100.0 - ~~(100.0 *
    //                             (benchMark.Input.CPU_f.idle - benchMark.Input.CPU_i.idle)/
    //                             (benchMark.Input.CPU_f.total - benchMark.Input.CPU_i.total));
    // benchMark.Input.MEM_100 = benchMark.Input.MEM_f - benchMark.Input.MEM_i;

    // // Misurazioni finali sull'elaborazione
    // benchMark.Elab.T_d = benchMark.Elab.T_f - benchMark.Elab.T_i;
    // benchMark.Elab.CPU_100 =   100.0 - ~~(100.0 *
    //                             (benchMark.Elab.CPU_f.idle - benchMark.Elab.CPU_i.idle)/
    //                             (benchMark.Elab.CPU_f.total - benchMark.Elab.CPU_i.total));
    // benchMark.Elab.MEM_100 = benchMark.Elab.MEM_f - benchMark.Elab.MEM_i;

    // // Misurazioni finali sulla scrittura
    // benchMark.Output.T_d = benchMark.Output.T_f - benchMark.Output.T_i;
    // benchMark.Output.CPU_100 =   100.0 - ~~(100.0 *
    //                             (benchMark.Output.CPU_f.idle - benchMark.Output.CPU_i.idle)/
    //                             (benchMark.Output.CPU_f.total - benchMark.Output.CPU_i.total));
    // benchMark.Output.MEM_100 = benchMark.Output.MEM_f - benchMark.Output.MEM_i;

    // // Misurazione finale sul threading
    // if(numero_thread!=0){
    //     benchMark.Thread.T_d = benchMark.Thread.T_f - benchMark.Thread.T_i;
    //     benchMark.Thread.CPU_100 = 100.0 - ~~(100.0 *
    //                             (benchMark.Thread.CPU_f.idle - benchMark.Thread.CPU_i.idle) /
    //                             (benchMark.Thread.CPU_f.total - benchMark.Thread.CPU_i.total));
    //     benchMark.Thread.MEM_100 = benchMark.Thread.MEM_f - benchMark.Thread.MEM_i;
    // }

    //////////////////////////
    // Stampo le misurazioni// --> eventualmente si potrebbero stampare solo i 3 valori di interesse
    //////////////////////////
    //console.log(benchMark);

    // // Versione finale
    // benchMark_final.Input.T_d = benchMark.Input.T_d;
    // benchMark_final.Input.CPU_100 = benchMark.Input.CPU_100;
    // benchMark_final.Input.MEM_100 = benchMark.Input.MEM_100;

    // // Misurazioni finali sull'elaborazione
    // benchMark_final.Elab.T_d = benchMark.Elab.T_d;
    // benchMark_final.Elab.CPU_100 = benchMark.Elab.CPU_100;
    // benchMark_final.Elab.MEM_100 = benchMark.Elab.MEM_100;

    // // Misurazioni finali sulla scrittura
    // benchMark_final.Output.T_d = benchMark.Output.T_d;
    // benchMark_final.Output.CPU_100 = benchMark.Output.CPU_100;
    // benchMark_final.Output.MEM_100 = benchMark.Output.MEM_100;

    // // Misurazione finale sul threading
    // if(numero_thread!=0){
    //     benchMark_final.Thread.T_d = benchMark.Thread.T_d;
    //     benchMark_final.Thread.CPU_100 = benchMark.Thread.CPU_100;
    //     benchMark_final.Thread.MEM_100 = benchMark.Thread.MEM_100;
    // }

    //////////////////////////
    // Stampo le misurazioni//
    //////////////////////////
    // console.log(benchMark_final);

});

