/* MODULI ***************************************************************************************************/
const fs = require('fs'); // per I/O da file
const { parentPort, threadId } = require('worker_threads'); // per Threading
const { cpuAverage } = require('./cpu');

/* MISURAZIONE ***************************************************************************************************/
// var benchMark = {
//     Output: {
//         T_i: undefined,
//         T_f: undefined,
//         T_d: undefined,
//         CPU_i: undefined,
//         CPU_f: undefined,
//         CPU_100: undefined,
//         MEM_i : undefined,
//         MEM_f : undefined,
//         MEM_100 : undefined
//     }
// };

/* ESECUZIONE ***************************************************************************************************/
// Quando ricevo nome file per essere attivato
parentPort.on('message', (par) => { 

    // Misurazione pre-scrittura
    // benchMark.Output.T_i = performance.now();
    // benchMark.Output.CPU_i = cpuAverage();
    // benchMark.Output.MEM_i = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100;

    // Scrittura
    fs.writeFile(par[0], par[1], 'utf8', (err) => {
        if (err) {
            console.error('Errore durante la scrittura del file:', err);
            return;
        }
    });

    // Misurazione post-scrittura
    // benchMark.Output.T_f = performance.now();
    // benchMark.Output.CPU_f = cpuAverage();
    // benchMark.Output.MEM_f = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100;

    // Misurazioni finali sulla scrittura
    // benchMark.Output.T_d = benchMark.Output.T_f - benchMark.Output.T_i;
    // benchMark.Output.CPU_100 =   100 - ~~(100 *
    //     (benchMark.Output.CPU_f.idle - benchMark.Output.CPU_i.idle)/
    //     (benchMark.Output.CPU_f.total - benchMark.Output.CPU_i.total));
    // benchMark.Output.MEM_100 = benchMark.Output.MEM_f - benchMark.Output.MEM_i;

    // Scrivo al padre le mie statistiche
    // parentPort.postMessage(benchMark);

    // Chiudo il thread
    parentPort.close();
});

