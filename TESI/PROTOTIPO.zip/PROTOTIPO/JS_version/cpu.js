/* LA CPU È GENERICA */
// È influenzata da altri processi (che non sappiamo) e quindi è impossibile isolare il consumo specifico ed è impossibile riprodurre gli stessi processi

var os = require("os");

//Create function to get CPU information
function cpuAverage() {

    //Initialise sum of idle and time of cores and fetch CPU info
    var totalIdle = 0, totalTick = 0;
    var cpus = os.cpus();
  
    //Loop through CPU cores
    for(var i = 0, len = cpus.length; i < len; i++) {
  
      //Select CPU core
      var cpu = cpus[i];
  
      //Total up the time in the cores tick
      for(type in cpu.times) {
        totalTick += cpu.times[type]; // sommo tutti i tempi (idle compreso)
     }     
  
      //Total up the idle time of the core
      totalIdle += cpu.times.idle; // prendo solo l'idle
    }
  
    //Return the average Idle and Tick times
    return {idle: totalIdle / cpus.length,  total: totalTick / cpus.length};
    
    // totalIdle / cpus.length -> idle medio tra le CPU
    // totalTick / cpus.length -> tempo totale di esecuzione totale (da quando ?)
}
module.exports = { cpuAverage }