/* QUICKSORT ALFANUMERICO CRESCENTE RICORSIVO */ 
// function quickSort(arr) {
//     if (arr.length <= 1) {
//         return arr;
//     }

//     const pivotIndex = Math.floor(arr.length / 2);
//     const pivot = arr[pivotIndex];
//     const left = [];
//     const right = [];

//     for (let i = 0; i < arr.length; i++) {
//         if (i === pivotIndex) {
//             continue; // Skip the pivot element
//         }

//         if (arr[i] < pivot) {
//             left.push(arr[i]);
//         } else {
//             right.push(arr[i]);
//         }
//     }

//     return [...quickSort(left), pivot, ...quickSort(right)];
// }



/* QUICKSORT ALFANUMERICO CRESCENTE ITERATIVO */
function quickSort(arr) {
    var stack = [];
    stack.push({ left: 0, right: arr.length - 1 });

    while (stack.length > 0) {
        var { left, right } = stack.pop();

        var pivotIndex = partition(arr, left, right);

        if (left < pivotIndex - 1) {
            stack.push({ left: left, right: pivotIndex - 1 });
        }

        if (pivotIndex + 1 < right) {
            stack.push({ left: pivotIndex + 1, right: right });
        }
    }

    return arr;
}

function partition(arr, left, right) {
    var pivot = arr[Math.floor((left + right) / 2)];
    var i = left;
    var j = right;

    while (i <= j) {
        while (arr[i].localeCompare(pivot, undefined, { numeric: true }) < 0) {
            i++;
        }

        while (arr[j].localeCompare(pivot, undefined, { numeric: true }) > 0) {
            j--;
        }

        if (i <= j) {
            var temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    }

    return i;
}

/* MERGESORT ALFANUMERICO CRESCENTE RICORSIVO */
// function mergeSort(arr) {
//     const n = arr.length;
//     if (n <= 1) {
//         return arr;
//     }

//     const mid = Math.floor(n / 2);
//     const left = mergeSort(arr.slice(0, mid));
//     const right = mergeSort(arr.slice(mid));

//     return merge(left, right);
// }

// function merge(left, right) {
//     let result = [];
//     let i = 0;
//     let j = 0;

//     while (i < left.length && j < right.length) {
//         if (left[i] < right[j]) {
//             result.push(left[i]);
//             i++;
//         } else {
//             result.push(right[j]);
//             j++;
//         }
//     }

//     return result.concat(left.slice(i)).concat(right.slice(j));
// }

function mergeSort(arr) {
    const n = arr.length;
    let currentSize;
    let leftStart;

    for (currentSize = 1; currentSize < n; currentSize *= 2) {
        for (leftStart = 0; leftStart < n - 1; leftStart += 2 * currentSize) {
            const mid = Math.min(leftStart + currentSize - 1, n - 1);
            const rightEnd = Math.min(leftStart + 2 * currentSize - 1, n - 1);

            const left = arr.slice(leftStart, mid + 1);
            const right = arr.slice(mid + 1, rightEnd + 1);

            const mergedArray = merge(left, right);
            
            for (let i = 0; i < mergedArray.length; i++) {
                arr[leftStart + i] = mergedArray[i];
            }
        }
    }

    return arr;
}

function merge(left, right) {
    let result = [];
    let leftIndex = 0;
    let rightIndex = 0;

    while (leftIndex < left.length && rightIndex < right.length) {
        if (left[leftIndex] < right[rightIndex]) {
            result.push(left[leftIndex]);
            leftIndex++;
        } else {
            result.push(right[rightIndex]);
            rightIndex++;
        }
    }

    return result.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
}

/* BUBBLESORT ALFANUMERICO CRESCENTE */
function bubbleSort(arr) {
    var n = arr.length;

    for (var i = 0; i < n - 1; i++) {
        for (var j = 0; j < n - i - 1; j++) {
            if (arr[j].localeCompare(arr[j + 1], undefined, { numeric: true }) > 0) {
                // Scambia gli elementi se sono fuori ordine
                var temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    return arr;
}


module.exports = { bubbleSort, mergeSort, quickSort };

