#!/bin/bash

# Verifica che sia fornito un comando da eseguire
if [ -z "$1" ]; then
    echo "Usage: $0 <command>"
    exit 1
fi

TIME_FILE=$(mktemp) # Outptut di time
# TOP_FILE=$(mktemp) # File TOP
PS_FILE=$(mktemp) # File PS
MEM_FILE=$(mktemp) # Nome del file temporaneo per l'utilizzo della memoria

# Comando da eseguire
COMANDO="$@"

# Monitoriamo cpu e tempo
# PS: proviamo a prendere anche la memoria istantanea, imprendibile dopo se il processo è troppo veloce
{       
        TIMEFORMAT='%P %E'
        time $COMANDO > /dev/null
        
} 2> $TIME_FILE & #stampa 'CPU% 0.XXXs'

PID_RSS=$(ps -o pid,rss,command | grep "$COMANDO" | grep -v grep | grep -v benchmark)
PID=$(echo "$PID_RSS" | awk '{print $1}')
    #echo "PID: $PID" # Per controllare 
RSS=$(echo "$PID_RSS" | awk '{print $2}') 
    echo "$RSS" >> $MEM_FILE    # ===>  da usare se comando è troppo veloce e non riesco a ricavarlo dopo
                                #       ma alcuni comandi sono anche troppo veloci per questo e provo a 
                                #       prenderli in background

# Monitoriamo la memoria
## Versione con TOP --> non ottimale per processio veloci, perchè tropoo tento
# echo "" > top_while.txt
# while [[ ! -z $(ps | grep "$COMANDO" | grep -v grep | grep -v benchmark | awk '{print $1}') ]] ; do
#     echo "ok" # verifica processo sta andando
#     ps -o pid,rss | tee -a top_while.txt | grep "$PID" >> $TOP_FILE
#     # top -l 1 -stats pid,command,cpu,mem | tee -a top_while.txt | grep "$PID" >> $TOP_FILE
# done

## Versione con PS --> veloce, da testare
# echo "" > ps_while.txt
while [[ ! -z $(ps | grep "$COMANDO" | grep -v grep | grep -v benchmark) ]] ; do
    #echo "ok" # verifica processo sta andando
    ps -o pid,rss | grep "$PID" >> $PS_FILE
done

# ps -o pid,rss,command  # verifica processo terminato

# Estrapolo MEM
# • Versione con TOP --> non ottimale per processio veloci, perchè tropoo tento
    # cat $TOP_FILE | tee top_file.txt | awk '{gsub(/[Kk]/,"",$4); gsub(/[M]/,"000",$4); gsub(/[+]/,"",$4); gsub(/[-]/,"",$1); print $4}' > $MEM_FILE
    # MEM_AVERAGE=$(awk '{ total += $1; count++ } END { if (count > 0) print "", total / count }' $MEM_FILE)

## • Versione con PS --> veloce, da testare
    cat $PS_FILE | awk '{print $2 }' >> $MEM_FILE # convetiamo le pagine in KB
    MEM_AVERAGE=$(awk '{ total += $1; count++ } END { if (count > 0) print "", total / count }' $MEM_FILE)

# Recuperiamo sol la cpu
CPU=$(cat $TIME_FILE | awk '{print $1}' | sed 's/\./,/g')
TIME=$(echo "$(cat $TIME_FILE | awk '{print $2}') * 1000" | bc | sed 's/\./,/g') # millisecondi

# Mostra i risultati, eventualmente da togliere unità di misura
echo "CPU: $CPU%"
echo "MEM: $MEM_AVERAGE KB"
echo "TIME: $(printf "%f" "$TIME") ms"

rm $TIME_FILE $MEM_FILE $PS_FILE