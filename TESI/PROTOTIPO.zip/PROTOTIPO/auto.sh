#!/bin/bash

# Controllo parametri
if [ -z "$1" ]; then
    echo "Usage: $0 numero_esecuzioni_per_combinazione"
    exit 1
fi
N="$1"

# Deve assolutamente essere eseguito qui
echo "hai lanciato il comando in:" $(pwd)

# Assegno ai file usati dallo script dei path assoluti per facilitare l'utilizzo
MISURAZIONI="$(pwd)/misurazioni.txt" 
PROIBITI="$(pwd)/combinazioni_impossibili.txt"
OUTPUT_DIR="$(pwd)/RUST_version/files_output"

# Resettiamo il dataset
echo "" > $MISURAZIONI

echo -e "I file sono:\n$MISURAZIONI\n$PROIBITI\n$OUTPUT_DIR"
#sleep 5 # se sbagli hai tempo per terminare processo


# Definisci i comandi e i valori possibili per i parametri
comandi=(
    "node app.js" 
    "wasmedge --dir .:. target/wasm32-wasi/release/RUST_version.wasm" 
    "wasmedge --dir .:. target/wasm32-wasi/release/RUST_version_aot.wasm" 
    "wasmtime --dir=. target/wasm32-wasi/release/RUST_version.wasm" 
    "wasmer run --dir=. target/wasm32-wasi/release/RUST_version.wasm" 
)
carichi=("1" "2" "3" "4" "5" "6" "7")
algoritmi=("1" "2" "3")
# threads=("0" "10" "100" "1000")

count=0

# Ciclo su tutti i comandi
for comando in "${comandi[@]}"; do

    # Scelta del prototipo in base al comando
    if [[ "$comando" == *node* ]]; then 
        cd JS_version
    else
        cd RUST_version
    fi

    # Ciclo su tutti i valori di param_1
    for param_1 in "${carichi[@]}"; do
        # Ciclo su tutti i valori di param_2
        for param_2 in "${algoritmi[@]}"; do
            # Filtriamo le combinazioni praticamente impossibili
            if [[ -z $(cat $PROIBITI | grep -v "#" | grep "$comando $param_1 $param_2") ]]; then
                # Inizializza gli accumulatori per la media
                media_CPU=0
                media_MEM=0
                media_TIME=0

                # Costruisci il comando completo
                comando_completo="../benchmark.sh $comando $param_1 $param_2"

                echo "******************************************************************************************************"
                echo "Eseguo $comando_completo"
                ((count++))


                # Esegui il comando N volte (N è un parametro)
                for ((i=1; i<=N; i++)); do
                    
                    # Esegui il comando e salva i risultati
                    risultato=$($comando_completo)

                    # Estrai i valori CPU, MEM, TIME dai risultati
                    CPU=$(echo "$risultato" | grep "CPU" | awk '{print $2}' | sed 's/%//g' | sed 's/,/./g')
                    MEM=$(echo "$risultato" | grep "MEM" | awk '{print $2}' | sed 's/KB//g' | sed 's/,/./g')
                    TIME=$(echo "$risultato" | grep "TIME" | awk '{print $2}' | sed 's/ms//g' | sed 's/,/./g')

                    # Aggiorna gli accumulatori
                    if [[ -n "$CPU" && -n "$MEM" && -n "$TIME" ]]; then
                        media_CPU=$(echo "$media_CPU + $CPU" | bc)
                        media_MEM=$(echo "$media_MEM + $MEM" | bc)
                        media_TIME=$(echo "$media_TIME + $TIME" | bc)
                    else 
                        exit 2
                    fi

                    # Per avere un'idea di come proceda
                    echo -e "=> esecuzione n.$i: $CPU%\t\t$MEM KB\t$TIME ms\n"

                    # Elimino il file creato
                    rm $OUTPUT_DIR/*    # mi chiede la conferma, non cambio questa opione per avere un controllo su cosa elimino 
                done

                # Calcola la media
                media_CPU=$(echo "$media_CPU / $N" | bc)
                #$(awk "BEGIN {print $media_CPU / $N}")
                media_MEM=$(echo "$media_MEM / $N" | bc)
                #$(awk "BEGIN {print $media_MEM / $N}")
                media_TIME=$(echo "$media_TIME / $N" | bc)
                #$(awk "BEGIN {print $media_TIME / $N}")

                # Stampa i risultati medi
                echo "Media:"
                echo "CPU: $media_CPU%"
                echo "MEM: $media_MEM KB"
                echo "TIME: $media_TIME ms"

                # Stampiamo su file i risultati
                echo -e "$comando_completo\n$media_CPU\n$media_MEM\n$media_TIME\n\n" >> "$MISURAZIONI"
            fi
        done
    done

    # Facciamo uscire dal prototipo corrente
    cd ..

done

echo "Le combinazioni sono $count"
echo "In totale le esecuzioni sono $(($count * $N))"