# CREAZIONE DEI FILE DI INPUT #
````
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 1000 > 1KB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 10000 > 10KB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 100000 > 100KB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 1000000 > 1MB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 10000000 > 10MB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 100000000 > 100MB.txt
cat /dev/urandom | LC_CTYPE=C tr -dc '[:alnum:]' | head -c 500000000 > 500MB.txt

````


# FUNZIONAMENTO #
````
./auto.sh 15

````
- In 'misurazioni.txt' ci saranno i dati pronti da inserire
- In 'combinazioni_possibili.txt' sono state scritte a mano le combinazioni da non realizzare (commentare con '#')

PS: misurazioni.txt risulta vuoto in quanto per errore è stato fattopartire il programma che ha sovrascritto il file. Le misurazioni usate sono comunque presenti nel foglio Excel.