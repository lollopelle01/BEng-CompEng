Questi file non sono da copiare direttamente, ma bisogna copiarne il contenuto
