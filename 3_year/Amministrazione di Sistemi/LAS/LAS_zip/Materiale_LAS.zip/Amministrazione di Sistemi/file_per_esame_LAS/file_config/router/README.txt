nel caso in cui all'esame servano piu' router, copiare la cartella, rinominarle, modificare i file e i playbook mettendo informazioni e path giusti
