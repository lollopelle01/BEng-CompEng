#!/bin/bash
#forma:
#comando directory

#controllo che il parametro passato sia una directory
test -d $1 || { echo "Inserire il nome di una directory" ; exit 1; }

ls -R "$1" | rev | cut  -s -f1 -d. | rev | sort | uniq -c | sort -n -r | head -5
#faccio una ls ricorsiva nel path indicato
#l'output lo passo ad una rev che inverte
#poi cut per tagliare in prossimita' del .
#rev per girare dal lato giusto
#sort per ordinare
#uniq -c per togliere doppioni e contare
#una seconda sort per ordinare per numero in ordine decrescente
#head -5 per prendere solo i primi 5 che sono i piu' numerosi 
