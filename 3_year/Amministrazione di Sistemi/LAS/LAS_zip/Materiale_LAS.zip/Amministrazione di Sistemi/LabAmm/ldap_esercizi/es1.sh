#!/bin/bash

# individua gli utenti presenti nella directory
# per ognuno modifica l'attributo gecos
# in modo che sia la concatenazione di cn, sn, mail
# se per un utente uno o più dei suddetti attributi fosse privo di valore, lo script dovrà notificarlo a terminale e acquisirne interattivamente il valore da tastiera

#ottengo una lista di utenti
ldapsearch -x -b dc=labammsis > utenti.txt
#per ogni utente apro il file e leggo per linea
while read LINE; do    
    #prendo il uid
    if [[ "$LINE"=~ "^dn:" ]] ; then
        UID=$("$LINE" | cut -d: -f2 | cut -d= -f2)
    fi    
    #prendo il cn
    if [[ "$LINE"=~ "^cn:" ]] ; then
        CN=$("$LINE" | cut -d: -f2)
    fi
    #prendo il sn
    if [[ "$LINE"=~ "^mail:" ]] ; then
        SN=$("$LINE" | cut -d: -f2)
    fi
    #prendo la mail    
    if [[ "$LINE"=~ "^mail:" ]] ; then
        MAIL=$("$LINE" | cut -d: -f2)
    fi
    #scrivo in un file la modifica da fare
    echo "dn: uid=$UID,ou=People,dc=labammsis\nchangetype: modify\nreplace: gecos\n
          gecos: $CN$SN$MAIL" > new"$UID".ldif
    #comando ldapmodify per modificare la entry
    ldapmodify -x -D cn=admin,dc=labammsis -w gennaio.marzo -f chsh.ldif
done < utenti.txt
