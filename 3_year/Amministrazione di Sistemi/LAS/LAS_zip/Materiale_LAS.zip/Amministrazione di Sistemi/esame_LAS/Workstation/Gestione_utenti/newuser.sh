#!/bin/bash
# Richiesta interattiva della password
echo -n "Inserire password: "
read -r PSW
#Invia via syslog al Manager queste informazioni, perché vengano scritte sul file /var/log/requests.log
#inserisco nuova facility
echo "local1.=info /var/log/requests.log" > /etc/rsyslog.d/logconfig.conf
#invio i parametri ottenuti
logger -n 172.16.1.1 -p local1.info "$1_$PSW" < /dev/null
