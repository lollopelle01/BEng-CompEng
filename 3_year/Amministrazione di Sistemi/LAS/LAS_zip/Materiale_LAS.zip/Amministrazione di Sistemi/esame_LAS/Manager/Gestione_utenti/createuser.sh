#!/bin/bash
# ad ogni nuova riga inserita
tail -f /var/log/requests.log | while read LINE ; do
    #prendo username e password
    USR=$(cut -f1 --delimiter=_ <<< $LINE)
    PSW=$(cut -f2 --delimiter=_ <<< $LINE)
    #inserisco i valori in un file
    echo "dn: uid=dave,ou=People,dc=labammsis\nobjectClass: top\nobjectClass: posixAccount\nobjectClass: shadowAccount\nobjectClass: inetOrgPerson\ngivenName: $USR\nmail: $USR@unibo.it\nuid: $USR\nuidNumber: 10000\ngidNumber: 10000\nhomeDirectory: /tmp\nloginShell: /bin/bash\ngecos: $USR\nuserPassword: $PSW\n" > new"$USR".ldif
#inserisco la entry in LDAP
ldapadd -x -D cn=admin,dc=labammsis −b dc=labammsis −w gennaio.marzo −H ldapi:/// -f new$USR.ldif
done
