#!/bin/bash
#interroga in parallelo tutte le workstation potenzialmente attive
#faccio una richiesta a tutti i possibili IP
for NUM ; do
IP=176.16.1."$NUM"
NUMPROC=$( snmpget -v 1 -c public "$IP" NET-SNMP-EXTEND-MIB::nsExtendOutputFull.\"numproc\" )
#se NUMPROC e' un numero e quindi e' attiva e ha un agent snmp installato, scrivo sul log
[[ "$NUMPROC"='^[0-9]+$' ]] && logger -p local1.info "$IP_$NUMPROC" < /dev/null
done < $(seq 2 128) #definire meglio il range


