'use strict';

class Mappa extends React.Component {

    render() {
    return (
        <div id="mappa">
        {this.props.matrix}
        </div>
        );
    }
}