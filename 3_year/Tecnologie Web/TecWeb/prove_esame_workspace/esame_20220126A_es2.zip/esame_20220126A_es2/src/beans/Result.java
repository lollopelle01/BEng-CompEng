package beans;

public class Result {
    private boolean flag;
    private int somma;
    
    public Result() {
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public int getSomma() {
        return somma;
    }

    public void setSomma(int somma) {
        this.somma = somma;
    }

    
}
