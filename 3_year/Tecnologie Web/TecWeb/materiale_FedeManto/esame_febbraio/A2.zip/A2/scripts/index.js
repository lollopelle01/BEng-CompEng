let btn = document.getElementById('btn');
let risultato = document.getElementById('risultato');
btn.addEventListener('click', handleClick);

function handleClick() {
	let righe = parseInt(document.getElementById('N').value);
	let colonne = parseInt(document.getElementById('M').value);
	let response = [];
	let matrice1 = document.getElementById('matrice1').value.split(",");
	let matrice2 = document.getElementById('matrice2').value.split(",");
	
	if(matrice1.length == righe * colonne && matrice2.length == righe * colonne) {
		// controllo che abbia messo le matrici dell'effettiva grandezza giusta
		risultato.innerText = "La dimensione dichiarata e le matrici inserite non coincidono di dimensione, inserire valori validi";
	} else {
		// posso inviare i dati con AJAX (formato JSON)
		let xhr = [];
		let numOfXHR = 2;
		
		for(let i = 0; i < numOfXHR; i++) {
			xhr[i].open("POST", "S1", true);
			xhr[i].setRequestHeader("Content-Type", "application/json");
		}
		
		for(let i = 0; i < numOfXHR; i++) {
			xhr[i].onreadystatechange = function() {
				if(xhr[i].readyState === 4 && xhr[i].status === 200) {
					// Risposta ricevuta, esegui il codice qui
					response.push(xhr[i].responseText);
					
					// TODO parsare risposta (arriva in JSON)
					risultato.innerText += "Differenza della matrice " + (i + 1);
					let jsObject = JSON.parse(response);
					risultato.innerText += "<br/> Matrice differenza " + jsObject.matrice1;
				}
			}
			// mando i dati
			if(i == 0) {
				// mando prima metà matrici
				let m1 = [];
				let m2 = [];
				for(let i = 0; i < (righe * colonne); i++) {
					m1[i] = matrice1[i];
					m2[i] = matrice2[i];
				}
				
				var dataForS1 = {
					"matrice1": m1,
					"matrice2": m2,
					"righe": righe,
					"colonne": colonne
				};
				
				xhr[i].send(JSON.stringify(dataForS1));
			} else {
				// mando seconda metà matrici
				let m1 = [];
				let m2 = [];
				for(let i = Math.floor(righe * colonne); i < (righe * colonne); i++) {
					m1[i] = matrice1[i];
					m2[i] = matrice2[i];
				}
				
				var dataForS1 = {
					"matrice1": m1,
					"matrice2": m2,
					"righe": righe,
					"colonne": colonne
				};
				xhr[i].send(JSON.stringify(dataForS1));
			}
			
		}
	}
}