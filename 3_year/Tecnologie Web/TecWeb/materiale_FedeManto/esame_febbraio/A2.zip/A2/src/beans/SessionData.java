package beans;

import java.util.Date;

import javax.servlet.http.HttpSession;

public class SessionData {
	private HttpSession session;
	private Date dataCreazione;
	private int numAccessi;
	
	public HttpSession getSession() {
		return session;
	}
	public void setSession(HttpSession session) {
		this.session = session;
	}
	public Date getDataCreazione() {
		return dataCreazione;
	}
	public void setDataCreazione(Date dataCreazione) {
		this.dataCreazione = dataCreazione;
	}
	public int getNumAccessi() {
		return numAccessi;
	}
	public void setNumAccessi(int numAccessi) {
		this.numAccessi = numAccessi;
	}
	
	public String toString(Date currentDate) {
		long diff = currentDate.getTime() - dataCreazione.getTime();
		
		return "SessionData [session=" + session + ", dataCreazione=" + dataCreazione + ", numAccessi=" + numAccessi
				+ "Tempo attivazione=" + diff + "]";
	}
	
	public SessionData(HttpSession session, Date dataCreazione, int numAccessi) {
		super();
		this.session = session;
		this.dataCreazione = dataCreazione;
		this.numAccessi = numAccessi;
	}
	
}
