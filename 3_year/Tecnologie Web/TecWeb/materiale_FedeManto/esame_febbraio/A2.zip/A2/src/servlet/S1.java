package servlet;

import java.io.BufferedReader;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import beans.Matrice;
import beans.SessionData;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		// gestione sessioni
		HttpSession session = request.getSession();
		HashMap<String, SessionData> sessions = (HashMap<String, SessionData>) this.getServletContext().getAttribute("sessions");
		Date currentDate = new Date();
		if(sessions == null) {
			SessionData sessionData = new SessionData(session, currentDate, 1);
			sessions.put(session.getId(), sessionData);
			this.getServletContext().setAttribute("sessions", sessions);
		} else {
			// controllo se � una sessione gi� esistente
			if(sessions.get(session.getId()) != null) {
				// sessione gi� esistente, allora incremento l'utilizzo
				int numUtilizzi = sessions.get(session.getId()).getNumAccessi() + 1;
				SessionData newData = sessions.get(session.getId());
				newData.setNumAccessi(numUtilizzi);
				sessions.put(session.getId(), newData);
				this.getServletContext().setAttribute("sessions", sessions);
			} else {
				// primo accesso per questa sessione
				SessionData sessionData = new SessionData(session, currentDate, 1);
				sessions.put(session.getId(), sessionData);
				this.getServletContext().setAttribute("sessions", sessions);
			}
		}
		
		//doPost method
		// calcolo differenza matrici
		StringBuilder buffer = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			buffer.append(line);
		}
		String data = buffer.toString();
		Gson gson = new Gson();
		Matrice parsedData = gson.fromJson(data, Matrice.class);
		int righe = parsedData.getRighe();
		int colonne = parsedData.getColonne();
		String[] m1 = parsedData.getMatrice1();
		String[] m2 = parsedData.getMatrice2();
		int matrice1[];
		int matrice2[];
		int matriceDiff[];
		
		// metto l'array dentro un array di int
		for(int i = 0; i < (righe * colonne) / 2; i++) {
			matrice1[i] = Integer.parseInt(m1[i]);
			matrice2[i] = Integer.parseInt(m2[i]);
		}
		
		// Business logic (faccio la differenza delle matrici)
		for(int i = 0; i < matrice1.length; i++) {
			matriceDiff[i] = matrice1[i] - matrice2[i];
		}
		
		// la matrice di risposta � di tipo String[]
		String matriceJSON[];
		for(int i = 0; i < matriceDiff[i]; i++) {
			matriceJSON[i] = Integer.toString(matriceDiff[i]);
		}
		
		// Mando al client il risultato(parziale) in JSON
		Matrice risposta = new Matrice(matriceJSON, null, righe, colonne);
		Gson gson = new Gson();
		String json = gson.toJson(risposta);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(json);
	}
}