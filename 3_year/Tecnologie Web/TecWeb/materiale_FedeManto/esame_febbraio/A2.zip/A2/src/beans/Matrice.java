package beans;

public class Matrice {
	private String[] matrice1;
	private String[] matrice2;
	private int righe;
	private int colonne;
	
	public String[] getMatrice1() {
		return matrice1;
	}
	public void setMatrice1(String[] matrice1) {
		this.matrice1 = matrice1;
	}
	public String[] getMatrice2() {
		return matrice2;
	}
	public void setMatrice2(String[] matrice2) {
		this.matrice2 = matrice2;
	}
	public int getRighe() {
		return righe;
	}
	public void setRighe(int righe) {
		this.righe = righe;
	}
	public int getColonne() {
		return colonne;
	}
	public void setColonne(int colonne) {
		this.colonne = colonne;
	}
	
	public Matrice(String[] matrice1, String[] matrice2, int righe, int colonne) {
		super();
		this.matrice1 = matrice1;
		this.matrice2 = matrice2;
		this.righe = righe;
		this.colonne = colonne;
	}
}
