package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.SessionData;

public class Admin extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//doPost method
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Date currentDate = new Date();
		// passo a toString la data corrente cos� mi calcola da quanto � attiva la sessione
	
		if(username.equals("admin") && password.equals("admin")) {
			// visualizzo i dati all'utente
			HashMap<String, SessionData> sessions = (HashMap<String, SessionData>) this.getServletContext().getAttribute("sessions");
			if(sessions != null) {
				for(String id : sessions.keySet()) {
					out.println(sessions.get(id).toString(currentDate) + " | ");
				}
			}
		} else {
			out.println("<h1>Accesso negato!<h1>");
		}
	}
}