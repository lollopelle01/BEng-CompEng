package beans;

import javax.servlet.http.HttpSession;

public class User {
	private String username;
	private String password;
	private HttpSession session;
	private String[] figMancanti;
	private String[] figDoppie;
	private UserRequest userRequest;
	
	public User(String username, String password, UserRequest userRequest) {
		super();
		this.username = username;
		this.password = password;
		this.userRequest = userRequest;
	}

	public UserRequest getUserRequest() {
		return userRequest;
	}

	public void setUserRequest(UserRequest userRequest) {
		this.userRequest = userRequest;
	}

	public User(String username, String password, HttpSession session, String[] figMancanti, String[] figDoppie) {
		super();
		this.username = username;
		this.password = password;
		this.session = session;
		this.figMancanti = figMancanti;
		this.figDoppie = figDoppie;
	}

	public String[] getFigMancanti() {
		return figMancanti;
	}

	public void setFigMancanti(String[] figMancanti) {
		this.figMancanti = figMancanti;
	}

	public String[] getFigDoppie() {
		return figDoppie;
	}

	public void setFigDoppie(String[] figDoppie) {
		this.figDoppie = figDoppie;
	}

	public User(String username, String password, HttpSession session) {
		super();
		this.username = username;
		this.password = password;
		this.session = session;
		this.figMancanti = null;
		this.figDoppie = null;
	}

	public HttpSession getSession() {
		return session;
	}

	public void setSession(HttpSession session) {
		this.session = session;
	}

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
		this.session = null;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", session=" + session + "]";
	}

}
