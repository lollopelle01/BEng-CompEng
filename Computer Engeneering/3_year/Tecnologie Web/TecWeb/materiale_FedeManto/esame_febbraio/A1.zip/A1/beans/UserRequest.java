package beans;

import java.util.Date;

public class UserRequest {
	private Date dateRichiesta;
	private int numRichiesta;
	
	public UserRequest() {
		super();
		this.numRichiesta = 0;
	}
	
	public UserRequest(Date dateRichiesta, int numRichiesta) {
		super();
		this.dateRichiesta = dateRichiesta;
		this.numRichiesta = numRichiesta;
	}

	public Date getDateRichiesta() {
		return dateRichiesta;
	}
	
	public void setDateRichiesta(Date dateRichiesta) {
		this.dateRichiesta = dateRichiesta;
	}
	
	public int getNumRichiesta() {
		return numRichiesta;
	}
	
	public void setNumRichiesta(int numRichiesta) {
		this.numRichiesta = numRichiesta;
	}
	
	
}
