package beans;

public class MyObject {
	private String username;
	private String[] figMancanti;
	private String[] figDoppie;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String[] getFigMancanti() {
		return figMancanti;
	}
	public void setFigMancanti(String[] figMancanti) {
		this.figMancanti = figMancanti;
	}
	public String[] getFigDoppie() {
		return figDoppie;
	}
	public void setFigDoppie(String[] figDoppie) {
		this.figDoppie = figDoppie;
	}
	public MyObject(String username, String[] figMancanti, String[] figDoppie) {
		super();
		this.username = username;
		this.figMancanti = figMancanti;
		this.figDoppie = figDoppie;
	}
	
	
}
