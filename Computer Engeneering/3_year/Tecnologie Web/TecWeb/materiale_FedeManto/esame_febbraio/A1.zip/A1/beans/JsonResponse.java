package beans;

public class JsonResponse {
	private int numFigurine;

	public int getNumFigurine() {
		return numFigurine;
	}

	public void setNumFigurine(int numFigurine) {
		this.numFigurine = numFigurine;
	}

	public JsonResponse(int numFigurine) {
		super();
		this.numFigurine = numFigurine;
	}
	
	
}
