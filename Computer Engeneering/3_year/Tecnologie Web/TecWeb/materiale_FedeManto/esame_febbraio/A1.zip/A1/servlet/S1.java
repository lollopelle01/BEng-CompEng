package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;

import beans.JsonResponse;
import beans.MyObject;
import beans.User;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// Gli utenti sono noti staticamente
		HashMap<String, User> users = (HashMap<String, User>) this.getServletContext().getAttribute("users");
		String usernameWhoRequested = (String) request.getAttribute("username");
		Gson gson = new Gson();
		
		// max 10 richieste
		if(users.get(usernameWhoRequested).getUserRequest().getNumRichiesta() + 1 > 10) {
			// -1 valore fittizio per indicare errore
			JsonResponse myObj = new JsonResponse(-1);
			String json = gson.toJson(myObj);
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(json);
		}
		
		int numFigurine = 0;
		// Parso i dati ricevuti in formato JSON
		StringBuilder buffer = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
		buffer.append(line);
		}
		String data = buffer.toString();
		
		// MyObject | nome brutto lo so:( | contiene la lista di figMancanti e figDoppie
		// questo dato lo aggiungo all'utente se non c'� gi�
		MyObject parsedData = gson.fromJson(data, MyObject.class);
		
		
		// se null allora le figurine non sono ancora state registrate nell'account
		if(users.get(usernameWhoRequested).getFigDoppie() == null ||
				users.get(usernameWhoRequested).getFigMancanti() == null) {
			users.get(usernameWhoRequested).setFigDoppie(parsedData.getFigDoppie());
			users.get(usernameWhoRequested).setFigMancanti(parsedData.getFigMancanti());
			
			// aggiorno i dati
			this.getServletContext().setAttribute("users", users);
		}
		
		// ora in questo modo ho l'utente che ha richiesto il servizio
		// e ho due array di stringhe che contengono le figMancanti e figDoppie
		for(String username : users.keySet()) {
			// guardo che il controllo non venga fatto sulle figurine del richiedente stesso
			if(!username.equals(usernameWhoRequested)) {
				// check delle figurine mancanti / doppie
			}
		}
		
		// business login TODO
		// valore fittizzio per mandare una risposta "sensata" al client
		numFigurine = 5;
		
		// Rinvio i dati in formato JSON
		JsonResponse myObj = new JsonResponse(numFigurine);
		String json = gson.toJson(myObj);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(json);
		
	}
}