package servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.User;
import beans.UserRequest;

public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public void init() {
		HashMap<String, User> users = new HashMap<String, User>();
		UserRequest userRequest = new UserRequest();
		
		User user = new User("Kanye", "1234", userRequest);
		users.put(user.getUsername(), user);
		
		user = new User("Kid", "1234", userRequest);
		users.put(user.getUsername(), user);
		
		user = new User("Carti", "1234", userRequest);
		users.put(user.getUsername(), user);
		
		this.getServletContext().setAttribute("users", users);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Accesso in corso");
		HashMap<String, User> users = (HashMap<String, User>) this.getServletContext().getAttribute("users");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		HttpSession session;
		
		// pagina admin non richiesta (era da template)
		/*if(username.equals("admin") && password.equals("admin")) {
			System.out.println("Accesso admin");*/
			
		//} else {
			if(users.containsKey(username) && users.get(username).getPassword().equals(password)) {
				if(users.get(username).getSession() == null) {
					// creazione sessione
					System.out.println("Creazione sessione per " + username);
					// max inattivita di 30 min (60 sec * 30)
					request.getSession().setMaxInactiveInterval(60 * 30);
					session = request.getSession(true);
					users.get(username).setSession(session);
					this.getServletContext().setAttribute("users", users);
					
					// accesso al servizio
					System.out.println("Accesso consentito per " + username);
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/J1.jsp");
					request.setAttribute("username", username);
					dispatcher.forward(request, response);
				} else {
					// sessione gi� presente
					// utente inattivo da 30 min lo reindirizzo alla pagina di Login
					if(request.getSession().getMaxInactiveInterval() >= 60*30) {
						request.getSession().invalidate();
					}
					System.out.println("Sessione gi� presente per " + username);
					
					// accesso al servizio
					System.out.println("Accesso consentito per " + username);
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/J1.jsp");
					request.setAttribute("username", username);
					dispatcher.forward(request, response);
				}	
			} else {
				System.out.println("Accesso negato");
			}
		//}
		
	}
}