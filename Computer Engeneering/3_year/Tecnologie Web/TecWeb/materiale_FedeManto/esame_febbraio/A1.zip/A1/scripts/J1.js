let figMancanti = document.getElementById('figMancanti');
let btn = document.getElementById('btn');
let esito = document.getElementById('esito');
figMancanti.addEventListener('onchange', handleChange);
btn.addEventListener('click', handleClick);

function handleChange() {
	let figDoppie = document.getElementById('figDoppie');
	if(figMancanti.value != null && figMancanti.value != "" &&
			figDoppie.value != null && figDoppie.value != "") {
		// i dati sono stati inseriti quindi posso abilitare il bottone
			btn.visibility = "visible";
	}
}

function handleClick() {
	let arrayMancanti = figMancanti.value.split(",");
	let arrayDoppie = figMancanti.value.split(",");
	
	// mando tramite AJAX la richiesta a S1 (JSON)
	xhr = new XMLHttpRequest();
	xhr.open("S1", "POST", true);
	xhr.setRequestHeader("Content-Type", "application/json");
	
	// ricezione dati (arrivano in formato JSON)
	if(xhr.readyState === 4 && xhr.status === 200) {
		var response = xhr.responseText;
		console.log("Gli altri utenti hanno: " + response.numFigurine);
		if(response.numFigurine == -1) {
			esito.innerText = "Hai superato il numero massimo di request";
		} else {
			esito.innerText = "Gli altri utenti hanno: " + response.numFigurine + " figurine";
		}
		
	}
	
	// Invio ad S1 dati in formato JSON
	let username = document.getElementById('usernmae').value;
	let dataForS1 = {
			"figMancanti": figMancanti,
			"figDoppie": figDoppie,
			"username": username.value
	};
	
	xhr.send(JSON.stringify(dataForS1));
}