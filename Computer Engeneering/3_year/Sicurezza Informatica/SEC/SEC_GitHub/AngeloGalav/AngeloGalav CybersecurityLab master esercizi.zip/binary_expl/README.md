# RICORDA!!!

Per fare questi esercizi, è necessario disabilitare l'ASLR. 
```
echo 0 > /proc/sys/kernel/randomize_va_space
```